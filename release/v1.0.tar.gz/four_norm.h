#include <stdio.h>
//#include <io.h>
#include <stdlib.h>
#include <math.h>

void print_help();
char * read_line(FILE * file_name);
char * word_next(char * line);
int char2int(char * line);
double char2double(char * line);
